﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            FarPoint.Win.Spread.EnhancedScrollBarRenderer enhancedScrollBarRenderer1 = new FarPoint.Win.Spread.EnhancedScrollBarRenderer();
            FarPoint.Win.Spread.NamedStyle namedStyle1 = new FarPoint.Win.Spread.NamedStyle("DataAreaMidnght");
            FarPoint.Win.Spread.CellType.GeneralCellType generalCellType1 = new FarPoint.Win.Spread.CellType.GeneralCellType();
            FarPoint.Win.Spread.NamedStyle namedStyle2 = new FarPoint.Win.Spread.NamedStyle("DataAreaGrayscale");
            FarPoint.Win.Spread.CellType.GeneralCellType generalCellType2 = new FarPoint.Win.Spread.CellType.GeneralCellType();
            FarPoint.Win.Spread.EnhancedScrollBarRenderer enhancedScrollBarRenderer2 = new FarPoint.Win.Spread.EnhancedScrollBarRenderer();
            this.fpSpread1_Sheet2 = new FarPoint.Win.Spread.SheetView();
            this.fpSpread1_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.fpSpread1 = new FarPoint.Win.Spread.FpSpread();
            this.btn_Continuation_Area = new System.Windows.Forms.Button();
            this.btn_PDF = new System.Windows.Forms.Button();
            this.fbd_PDF = new System.Windows.Forms.FolderBrowserDialog();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).BeginInit();
            this.SuspendLayout();
            // 
            // fpSpread1_Sheet2
            // 
            this.fpSpread1_Sheet2.Reset();
            this.fpSpread1_Sheet2.SheetName = "Sheet2";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread1_Sheet2.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread1_Sheet2.ActiveRowIndex = 1;
            this.fpSpread1_Sheet2.Cells.Get(1, 0).Value = "xdfzvb";
            this.fpSpread1_Sheet2.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet2.ColumnFooter.DefaultStyle.Parent = "ColumnHeaderArcticSea";
            this.fpSpread1_Sheet2.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet2.ColumnFooterSheetCornerStyle.Parent = "CornerArcticSea";
            this.fpSpread1_Sheet2.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet2.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderArcticSea";
            this.fpSpread1_Sheet2.FilterBar.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet2.FilterBar.DefaultStyle.Parent = "FilterBarArcticSea";
            this.fpSpread1_Sheet2.FilterBarHeaderStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet2.FilterBarHeaderStyle.Parent = "RowHeaderArcticSea";
            this.fpSpread1_Sheet2.RowHeader.Columns.Default.Resizable = false;
            this.fpSpread1_Sheet2.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet2.RowHeader.DefaultStyle.Parent = "RowHeaderArcticSea";
            this.fpSpread1_Sheet2.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet2.SheetCornerStyle.Parent = "CornerArcticSea";
            this.fpSpread1_Sheet2.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // fpSpread1_Sheet1
            // 
            this.fpSpread1_Sheet1.Reset();
            this.fpSpread1_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread1_Sheet1.ColumnCount = 495;
            this.fpSpread1_Sheet1.Cells.Get(0, 0).BackColor = System.Drawing.Color.DarkSlateBlue;
            this.fpSpread1_Sheet1.Cells.Get(0, 0).Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.fpSpread1_Sheet1.Cells.Get(0, 0).ForeColor = System.Drawing.Color.White;
            this.fpSpread1_Sheet1.Cells.Get(0, 0).Value = "Component";
            this.fpSpread1_Sheet1.Cells.Get(0, 1).BackColor = System.Drawing.Color.DarkSlateBlue;
            this.fpSpread1_Sheet1.Cells.Get(0, 1).Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.fpSpread1_Sheet1.Cells.Get(0, 1).ForeColor = System.Drawing.Color.White;
            this.fpSpread1_Sheet1.Cells.Get(0, 1).Value = "Length";
            this.fpSpread1_Sheet1.Cells.Get(0, 3).BackColor = System.Drawing.Color.DarkSlateBlue;
            this.fpSpread1_Sheet1.Cells.Get(0, 3).Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.fpSpread1_Sheet1.Cells.Get(0, 3).ForeColor = System.Drawing.Color.White;
            this.fpSpread1_Sheet1.Cells.Get(0, 3).Value = "Diameter";
            this.fpSpread1_Sheet1.Cells.Get(0, 5).BackColor = System.Drawing.Color.DarkSlateBlue;
            this.fpSpread1_Sheet1.Cells.Get(0, 5).Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.fpSpread1_Sheet1.Cells.Get(0, 5).ForeColor = System.Drawing.Color.White;
            this.fpSpread1_Sheet1.Cells.Get(0, 5).Value = "Pressure";
            this.fpSpread1_Sheet1.Cells.Get(0, 7).BackColor = System.Drawing.Color.DarkSlateBlue;
            this.fpSpread1_Sheet1.Cells.Get(0, 7).Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.fpSpread1_Sheet1.Cells.Get(0, 7).ForeColor = System.Drawing.Color.White;
            this.fpSpread1_Sheet1.Cells.Get(0, 7).Value = "MATERIAL";
            this.fpSpread1_Sheet1.Cells.Get(0, 10).BackColor = System.Drawing.Color.White;
            this.fpSpread1_Sheet1.Cells.Get(0, 10).Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.fpSpread1_Sheet1.Cells.Get(0, 10).ForeColor = System.Drawing.Color.White;
            this.fpSpread1_Sheet1.Cells.Get(0, 11).BackColor = System.Drawing.Color.White;
            this.fpSpread1_Sheet1.Cells.Get(0, 11).Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.fpSpread1_Sheet1.Cells.Get(0, 11).ForeColor = System.Drawing.Color.White;
            this.fpSpread1_Sheet1.Cells.Get(0, 12).BackColor = System.Drawing.Color.White;
            this.fpSpread1_Sheet1.Cells.Get(0, 12).Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.fpSpread1_Sheet1.Cells.Get(0, 12).ForeColor = System.Drawing.Color.White;
            this.fpSpread1_Sheet1.Cells.Get(2, 0).Value = "SDF";
            this.fpSpread1_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.ColumnFooter.DefaultStyle.Parent = "ColumnHeaderArcticSea";
            this.fpSpread1_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerArcticSea";
            this.fpSpread1_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.ColumnHeader.DefaultStyle.Parent = "ColumnHeaderArcticSea";
            this.fpSpread1_Sheet1.Columns.Get(0).Width = 109F;
            this.fpSpread1_Sheet1.Columns.Get(1).Width = 58F;
            this.fpSpread1_Sheet1.Columns.Get(7).Width = 68F;
            this.fpSpread1_Sheet1.Columns.Get(9).Width = 68F;
            this.fpSpread1_Sheet1.FilterBar.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.FilterBar.DefaultStyle.Parent = "FilterBarArcticSea";
            this.fpSpread1_Sheet1.FilterBarHeaderStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.FilterBarHeaderStyle.Parent = "RowHeaderArcticSea";
            this.fpSpread1_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.fpSpread1_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderArcticSea";
            this.fpSpread1_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.SheetCornerStyle.Parent = "CornerArcticSea";
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // fpSpread1
            // 
            this.fpSpread1.AccessibleDescription = "fpSpread1, Sheet1, Row 0, Column 0, Component";
            this.fpSpread1.AllowColumnMove = true;
            this.fpSpread1.AllowDragDrop = true;
            this.fpSpread1.AllowRowMove = true;
            this.fpSpread1.AllowUserFormulas = true;
            this.fpSpread1.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread1.HorizontalScrollBar.Name = "";
            enhancedScrollBarRenderer1.ArrowColor = System.Drawing.Color.Navy;
            enhancedScrollBarRenderer1.ArrowHoveredColor = System.Drawing.Color.Navy;
            enhancedScrollBarRenderer1.ArrowSelectedColor = System.Drawing.Color.Navy;
            enhancedScrollBarRenderer1.ButtonBackgroundColor = System.Drawing.Color.LightSteelBlue;
            enhancedScrollBarRenderer1.ButtonBorderColor = System.Drawing.Color.SteelBlue;
            enhancedScrollBarRenderer1.ButtonHoveredBackgroundColor = System.Drawing.Color.DeepSkyBlue;
            enhancedScrollBarRenderer1.ButtonHoveredBorderColor = System.Drawing.Color.DeepSkyBlue;
            enhancedScrollBarRenderer1.ButtonSelectedBackgroundColor = System.Drawing.Color.SteelBlue;
            enhancedScrollBarRenderer1.ButtonSelectedBorderColor = System.Drawing.Color.LightSteelBlue;
            enhancedScrollBarRenderer1.TrackBarBackgroundColor = System.Drawing.Color.LightSkyBlue;
            enhancedScrollBarRenderer1.TrackBarSelectedBackgroundColor = System.Drawing.Color.SteelBlue;
            this.fpSpread1.HorizontalScrollBar.Renderer = enhancedScrollBarRenderer1;
            this.fpSpread1.HorizontalScrollBar.TabIndex = 42;
            this.fpSpread1.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpread1.Location = new System.Drawing.Point(12, 12);
            this.fpSpread1.Name = "fpSpread1";
            namedStyle1.BackColor = System.Drawing.Color.DarkGray;
            namedStyle1.CellType = generalCellType1;
            namedStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            namedStyle1.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle1.Renderer = generalCellType1;
            namedStyle2.BackColor = System.Drawing.Color.Gainsboro;
            namedStyle2.CellType = generalCellType2;
            namedStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            namedStyle2.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle2.Renderer = generalCellType2;
            this.fpSpread1.NamedStyles.AddRange(new FarPoint.Win.Spread.NamedStyle[] {
            namedStyle1,
            namedStyle2});
            this.fpSpread1.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread1_Sheet1,
            this.fpSpread1_Sheet2});
            this.fpSpread1.Size = new System.Drawing.Size(485, 494);
            this.fpSpread1.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.ArcticSea;
            this.fpSpread1.TabIndex = 0;
            this.fpSpread1.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread1.VerticalScrollBar.Name = "";
            enhancedScrollBarRenderer2.ArrowColor = System.Drawing.Color.Navy;
            enhancedScrollBarRenderer2.ArrowHoveredColor = System.Drawing.Color.Navy;
            enhancedScrollBarRenderer2.ArrowSelectedColor = System.Drawing.Color.Navy;
            enhancedScrollBarRenderer2.ButtonBackgroundColor = System.Drawing.Color.LightSteelBlue;
            enhancedScrollBarRenderer2.ButtonBorderColor = System.Drawing.Color.SteelBlue;
            enhancedScrollBarRenderer2.ButtonHoveredBackgroundColor = System.Drawing.Color.DeepSkyBlue;
            enhancedScrollBarRenderer2.ButtonHoveredBorderColor = System.Drawing.Color.DeepSkyBlue;
            enhancedScrollBarRenderer2.ButtonSelectedBackgroundColor = System.Drawing.Color.SteelBlue;
            enhancedScrollBarRenderer2.ButtonSelectedBorderColor = System.Drawing.Color.LightSteelBlue;
            enhancedScrollBarRenderer2.TrackBarBackgroundColor = System.Drawing.Color.LightSkyBlue;
            enhancedScrollBarRenderer2.TrackBarSelectedBackgroundColor = System.Drawing.Color.SteelBlue;
            this.fpSpread1.VerticalScrollBar.Renderer = enhancedScrollBarRenderer2;
            this.fpSpread1.VerticalScrollBar.TabIndex = 43;
            this.fpSpread1.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpread1.ComboSelChange += new FarPoint.Win.Spread.EditorNotifyEventHandler(this.fpSpread1_ComboSelChange);
            // 
            // btn_Continuation_Area
            // 
            this.btn_Continuation_Area.Location = new System.Drawing.Point(1079, 24);
            this.btn_Continuation_Area.Name = "btn_Continuation_Area";
            this.btn_Continuation_Area.Size = new System.Drawing.Size(146, 23);
            this.btn_Continuation_Area.TabIndex = 1;
            this.btn_Continuation_Area.Text = "Continuation Area";
            this.btn_Continuation_Area.UseVisualStyleBackColor = true;
            this.btn_Continuation_Area.Click += new System.EventHandler(this.btn_Continuation_Area_Click);
            // 
            // btn_PDF
            // 
            this.btn_PDF.Location = new System.Drawing.Point(1079, 159);
            this.btn_PDF.Name = "btn_PDF";
            this.btn_PDF.Size = new System.Drawing.Size(146, 23);
            this.btn_PDF.TabIndex = 2;
            this.btn_PDF.Text = "PDF";
            this.btn_PDF.UseVisualStyleBackColor = true;
            this.btn_PDF.Click += new System.EventHandler(this.btn_PDF_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1258, 651);
            this.Controls.Add(this.btn_PDF);
            this.Controls.Add(this.btn_Continuation_Area);
            this.Controls.Add(this.fpSpread1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private FarPoint.Win.Spread.SheetView fpSpread1_Sheet2;
        private FarPoint.Win.Spread.SheetView fpSpread1_Sheet1;
        private FarPoint.Win.Spread.FpSpread fpSpread1;
        private System.Windows.Forms.Button btn_Continuation_Area;
        private System.Windows.Forms.Button btn_PDF;
        private System.Windows.Forms.FolderBrowserDialog fbd_PDF;



    }
}

