﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FarPoint.Win.Spread;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            fpSpread1.Sheets[1].Visible = false;
            fpSpread1.AllowDragFill = true;


            fpSpread1.Height = 600;
            fpSpread1.Width = 700;
            fpSpread1_Sheet1.RowCount = 24;
            fpSpread1.Sheets[0].ColumnCount = 12;
            fpSpread1.Sheets[0].Columns[1].Width = 50;
            //fpSpread1.Sheets[0].Columns[7].Visible = true;

            fpSpread1.Sheets[0].ColumnHeader.Cells[0, 0].Text = "Element";
            fpSpread1.Sheets[0].ColumnHeader.Cells[0, 1].Text = "Length";
            fpSpread1.Sheets[0].ColumnHeader.Cells[0, 2].Text = "Unit";
            fpSpread1.Sheets[0].ColumnHeader.Cells[0, 3].Text = "Diameter";
            fpSpread1.Sheets[0].ColumnHeader.Cells[0, 4].Text = "Unit";
            fpSpread1.Sheets[0].ColumnHeader.Cells[0, 5].Text = "Pressure";
            fpSpread1.Sheets[0].ColumnHeader.Cells[0, 6].Text = "Unit";
            fpSpread1.Sheets[0].ColumnHeader.Cells[0, 7].Text = "Material";

            fpSpread1.Sheets[0].Cells[22, 0].Text = "";
            fpSpread1.Sheets[0].Cells[20, 0].Text = "";

            fpSpread1.ActiveSheet.SetActiveCell(1, 0);


            FarPoint.Win.Spread.CellType.NumberCellType objLength = new FarPoint.Win.Spread.CellType.NumberCellType();
            objLength.DecimalPlaces = 2;
            fpSpread1.Sheets[0].Columns[1].CellType = objLength;
            fpSpread1.Sheets[0].Columns[3].CellType = objLength;
            for (int i = 1; i < 22; i++)
            {
                fpSpread1.Sheets[0].Cells[i, 1].Value = 55.00;
            }

            for (int i = 1; i < 22; i++)
            {
                fpSpread1.Sheets[0].Cells[i, 3].Value = 4556.00;
            }

            for (int i = 1; i < 22; i++)
            {
                fpSpread1.Sheets[0].Cells[i, 5].Value = 238.00;
            }

            FarPoint.Win.Spread.CellType.TextCellType objMaterial = new FarPoint.Win.Spread.CellType.TextCellType();
            objMaterial.MaxLength = 100;
            fpSpread1.Sheets[0].Columns[7].CellType = objMaterial;


            FarPoint.Win.Spread.CellType.ComboBoxCellType objLengthUnit = new FarPoint.Win.Spread.CellType.ComboBoxCellType();
            objLengthUnit.Items = (new String[] { "mm", "cm", "m", "in", "ft" });
            objLengthUnit.MaxDrop = 5;
            objLengthUnit.AutoSearch = FarPoint.Win.AutoSearch.SingleCharacter;
            fpSpread1.ActiveSheet.Columns[2].CellType = objLengthUnit;
            fpSpread1.ActiveSheet.Columns[4].CellType = objLengthUnit;

            FarPoint.Win.Spread.CellType.ComboBoxCellType objPressureUnit = new FarPoint.Win.Spread.CellType.ComboBoxCellType();
            objPressureUnit.Items = (new String[] { "Bars", "Pascal", "MPa", "lbs/sq.in", "lbs/sq.ft" });
            objPressureUnit.MaxDrop = 5;
            objPressureUnit.AutoSearch = FarPoint.Win.AutoSearch.SingleCharacter;
            fpSpread1.ActiveSheet.Columns[6].CellType = objPressureUnit;

            FarPoint.Win.Spread.CellType.DateTimeCellType objDateTime = new FarPoint.Win.Spread.CellType.DateTimeCellType();
            objDateTime.DateTimeFormat = FarPoint.Win.Spread.CellType.DateTimeFormat.ShortDate;
            fpSpread1.Sheets[0].Rows[22].CellType = objDateTime;
            fpSpread1.Sheets[0].Cells[22, 1].Value = System.DateTime.Now;

            FarPoint.Win.Spread.CellType.DateTimeCellType objTime = new FarPoint.Win.Spread.CellType.DateTimeCellType();
            objTime.DateTimeFormat = FarPoint.Win.Spread.CellType.DateTimeFormat.TimeOnly;
            fpSpread1.Sheets[0].Rows[23].CellType = objTime;
            fpSpread1.Sheets[0].Cells[23, 1].Value = System.DateTime.Now;

            FarPoint.Win.Spread.CellType.ImageCellType imgcell = new FarPoint.Win.Spread.CellType.ImageCellType();
            System.Drawing.Image imagecell = System.Drawing.Image.FromFile(@"C:\Users\Mudassir.Khan\Desktop\dataandcloudcomputing.jpg");
            imgcell.Style = FarPoint.Win.RenderStyle.Stretch;
            fpSpread1.Sheets[0].Cells[1, 10].CellType = imgcell;


        }



        private void btn_Continuation_Area_Click(object sender, EventArgs e)
        {
            FarPoint.Win.Spread.Model.CellRange CR = fpSpread1.ActiveSheet.GetSelection(0);

            fpSpread1.ActiveSheet.Cells[CR.Row, CR.Column, CR.Row + CR.RowCount - 1, CR.Column + CR.ColumnCount - 1].BackColor = Color.Beige;

            {
                if (CR.ColumnCount < 2 || CR.ColumnCount == 3 || CR.ColumnCount == 5)
                {
                    MessageBox.Show("Number of rows and columns selected for this functionality not enough", "ok", MessageBoxButtons.OK);
                }

                else if (CR.ColumnCount >= 2 && CR.ColumnCount < 5)
                {
                    FarPoint.Win.Spread.CellType.ComboBoxCellType objLengthUnit = new FarPoint.Win.Spread.CellType.ComboBoxCellType();
                    objLengthUnit.Items = (new String[] { "mm", "cm", "m", "in", "ft" });
                    objLengthUnit.MaxDrop = 5;
                    objLengthUnit.AutoSearch = FarPoint.Win.AutoSearch.SingleCharacter;
                    fpSpread1.ActiveSheet.Cells[CR.Row, CR.Column + 1, CR.Row + CR.RowCount - 1, CR.Column + 1].CellType = objLengthUnit;
                    fpSpread1.ActiveSheet.Cells[CR.Row, CR.Column + 3, CR.Row + CR.RowCount - 1, CR.Column + 3].CellType = objLengthUnit;
                    #region Population
                    for (int i = 0; i < CR.RowCount; i++)
                    {
                        fpSpread1.Sheets[0].Cells[CR.Row + i, CR.Column].Value = fpSpread1.Sheets[0].Cells[i + 1, 1].Value;

                    }

                    for (int i = 0; i < CR.RowCount; i++)
                    {
                        fpSpread1.Sheets[0].Cells[CR.Row + i, CR.Column + 2].Value = fpSpread1.Sheets[0].Cells[i + 1, 3].Value;
                    }



                }
                else if (CR.ColumnCount >= 2 && CR.ColumnCount <= 6)
                {

                }

                else if (CR.ColumnCount > 2 && CR.ColumnCount <= 7)
                {

                }
            }
        }

                    #endregion





        private void fpSpread1_ComboSelChange(object sender, EditorNotifyEventArgs e)
        {
            #region Length_Units_Column
            if (fpSpread1.ActiveSheet.Cells[0, 2].Value == "mm")
            {

                for (int i = 0; i < 20; i++)
                {
                    fpSpread1.ActiveSheet.Cells[i, 2].Value = "mm";

                    fpSpread1.ActiveSheet.Cells[i + 1, 1].Value = ((double)fpSpread1.ActiveSheet.Cells[i + 1, 1].Value) * (0.01);

                }


            }

            else if (fpSpread1.ActiveSheet.Cells[0, 2].Value == "cm")
            {
                for (int i = 0; i < 20; i++)
                {
                    fpSpread1.ActiveSheet.Cells[i, 2].Value = "cm";
                    fpSpread1.ActiveSheet.Cells[i + 1, 1].Value = ((double)fpSpread1.ActiveSheet.Cells[i + 1, 1].Value) * (0.1);
                }
            }
            else if (fpSpread1.ActiveSheet.Cells[0, 2].Value == "m")
            {
                for (int i = 0; i < 20; i++)
                {
                    fpSpread1.ActiveSheet.Cells[i, 2].Value = "m";
                    fpSpread1.ActiveSheet.Cells[i + 1, 1].Value = ((double)fpSpread1.ActiveSheet.Cells[i + 1, 1].Value) * (1.00);
                }
            }
            else if (fpSpread1.ActiveSheet.Cells[0, 2].Value == "in")
            {
                for (int i = 0; i < 20; i++)
                {
                    fpSpread1.ActiveSheet.Cells[i, 2].Value = "in";
                    fpSpread1.ActiveSheet.Cells[i + 1, 1].Value = ((double)fpSpread1.ActiveSheet.Cells[i + 1, 1].Value) * (39.37);
                }
            }
            else if (fpSpread1.ActiveSheet.Cells[0, 2].Value == "ft")
            {
                for (int i = 0; i < 20; i++)
                {
                    fpSpread1.ActiveSheet.Cells[i, 2].Value = "ft";
                    fpSpread1.ActiveSheet.Cells[i + 1, 1].Value = ((double)fpSpread1.ActiveSheet.Cells[i + 1, 1].Value) * (3.28);
                }
            }


            fpSpread1.ActiveSheet.Cells[0, 2].Value = null;
            #endregion

            #region Diameter_Units_Column

            if (fpSpread1.ActiveSheet.Cells[0, 4].Value == "mm")
            {

                for (int i = 0; i < 20; i++)
                {
                    fpSpread1.ActiveSheet.Cells[i, 4].Value = "mm";

                    fpSpread1.ActiveSheet.Cells[i + 1, 3].Value = ((double)fpSpread1.ActiveSheet.Cells[i + 1, 3].Value) * (0.01);

                }


            }

            else if (fpSpread1.ActiveSheet.Cells[0, 4].Value == "cm")
            {
                for (int i = 0; i < 20; i++)
                {
                    fpSpread1.ActiveSheet.Cells[i, 4].Value = "cm";
                    fpSpread1.ActiveSheet.Cells[i + 1, 3].Value = ((double)fpSpread1.ActiveSheet.Cells[i + 1, 3].Value) * (0.1);
                }
            }
            else if (fpSpread1.ActiveSheet.Cells[0, 4].Value == "m")
            {
                for (int i = 0; i < 20; i++)
                {
                    fpSpread1.ActiveSheet.Cells[i, 4].Value = "m";
                    fpSpread1.ActiveSheet.Cells[i + 1, 3].Value = ((double)fpSpread1.ActiveSheet.Cells[i + 1, 3].Value) * (1.00);
                }
            }
            else if (fpSpread1.ActiveSheet.Cells[0, 4].Value == "in")
            {
                for (int i = 0; i < 20; i++)
                {
                    fpSpread1.ActiveSheet.Cells[i, 4].Value = "in";
                    fpSpread1.ActiveSheet.Cells[i + 1, 3].Value = ((double)fpSpread1.ActiveSheet.Cells[i + 1, 3].Value) * (39.37);
                }
            }
            else if (fpSpread1.ActiveSheet.Cells[0, 4].Value == "ft")
            {
                for (int i = 0; i < 20; i++)
                {
                    fpSpread1.ActiveSheet.Cells[i, 4].Value = "ft";
                    fpSpread1.ActiveSheet.Cells[i + 1, 3].Value = ((double)fpSpread1.ActiveSheet.Cells[i + 1, 3].Value) * (3.28);
                }
            }


            fpSpread1.ActiveSheet.Cells[0, 4].Value = null;
            #endregion

            #region Pressure_Units_Column


            if (fpSpread1.ActiveSheet.Cells[0, 6].Value == "Bars")
            {

                for (int i = 0; i < 20; i++)
                {
                    fpSpread1.ActiveSheet.Cells[i, 6].Value = "Bars";

                    fpSpread1.ActiveSheet.Cells[i + 1, 5].Value = ((double)fpSpread1.ActiveSheet.Cells[i + 1, 5].Value) * (0.00001);

                }


            }

            else if (fpSpread1.ActiveSheet.Cells[0, 6].Value == "Pascal")
            {
                for (int i = 0; i < 20; i++)
                {
                    fpSpread1.ActiveSheet.Cells[i, 6].Value = "Pascal";
                    fpSpread1.ActiveSheet.Cells[i + 1, 5].Value = ((double)fpSpread1.ActiveSheet.Cells[i + 1, 5].Value) * (1);
                }
            }
            else if (fpSpread1.ActiveSheet.Cells[0, 6].Value == "MPa")
            {
                for (int i = 0; i < 20; i++)
                {
                    fpSpread1.ActiveSheet.Cells[i, 6].Value = "MPa";
                    fpSpread1.ActiveSheet.Cells[i + 1, 5].Value = ((double)fpSpread1.ActiveSheet.Cells[i + 1, 5].Value) * (10 ^ 6);
                }
            }
            else if (fpSpread1.ActiveSheet.Cells[0, 6].Value == "lbs/sq.in")
            {
                for (int i = 0; i < 20; i++)
                {
                    fpSpread1.ActiveSheet.Cells[i, 6].Value = "lbs/sq.in";
                    fpSpread1.ActiveSheet.Cells[i + 1, 5].Value = ((double)fpSpread1.ActiveSheet.Cells[i + 1, 5].Value) * (0.000145038);
                }
            }
            else if (fpSpread1.ActiveSheet.Cells[0, 6].Value == "lbs/sq.ft")
            {
                for (int i = 0; i < 20; i++)
                {
                    fpSpread1.ActiveSheet.Cells[i, 6].Value = "lbs/sq.ft";
                    fpSpread1.ActiveSheet.Cells[i + 1, 5].Value = ((double)fpSpread1.ActiveSheet.Cells[i + 1, 5].Value) * (0.0208854);
                }
            }


            fpSpread1.ActiveSheet.Cells[0, 6].Value = null;
            #endregion

        }

        private void btn_PDF_Click(object sender, EventArgs e)
        {
            fbd_PDF.ShowDialog();
            if (true)
            {
                FarPoint.Win.Spread.PrintInfo printsheet = new FarPoint.Win.Spread.PrintInfo();
                printsheet.PrintToPdf = true;
                printsheet.PdfFileName = "D:\\results.pdf";
                fpSpread1.Sheets[0].PrintInfo = printsheet;
                fpSpread1.PrintSheet(0);
            }





        }
    }
}