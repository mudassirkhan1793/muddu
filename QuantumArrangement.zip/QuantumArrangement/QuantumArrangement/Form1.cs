﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuantumArrangement
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }


        private void Form1_Load(object sender, EventArgs e)
        {

            #region CBO_USER_ID_POPULATION

            using (SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Muddu\QuantumArrangement\QuantumArrangement\Database_Resource_Management.mdf;Integrated Security=True"))
            {
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter("Select * from User_Details", connection);
                    DataSet ds = new DataSet();
                    da.Fill(ds, "User_Details");

                    cbo_User_Id.DisplayMember = "User_Id";
                    cbo_User_Id.ValueMember = "User_Id";
                    cbo_User_Id.DataSource = ds.Tables["User_Details"];


                }
                catch (Exception ex)
                {
                    MessageBox.Show("CONNECTION FAILED", ex.ToString());

                }


            }

            #endregion
        }

        private void cbo_User_Id_SelectedIndexChanged(object sender, EventArgs e)

        {

            #region USER_VALIDATION

            if (cbo_User_Id.SelectedValue.ToString().Equals("3"))
            {
                group_Booking.Enabled = true;
                group_Admin.Enabled = true;
            }
            else if (cbo_User_Id.SelectedValue != null)
            {
                group_Booking.Enabled = true;
                group_Admin.Enabled = false;
            }
            else
            {
                group_Admin.Enabled = false;
                group_Booking.Enabled = false;

            }

            #endregion

            #region CBO_RESOURCE_POPULATION
            using (SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Muddu\QuantumArrangement\QuantumArrangement\Database_Resource_Management.mdf;Integrated Security=True"))
            {
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter("Select * from ROOM_DETAILS", connection);
                    DataSet ds = new DataSet();
                    da.Fill(ds, "ROOM_DETAILS");

                    cbo_Resource.DisplayMember = "Room_Name";
                    cbo_Resource.ValueMember = "Room_Id";
                    cbo_Resource.DataSource = ds.Tables["ROOM_DETAILS"];


                }
                catch (Exception ex)
                {
                    MessageBox.Show("CONNECTION FAILED", ex.ToString());
                }


            }
            #endregion

        }

        private void dtp_Start_Time_Booking_ValueChanged(object sender, EventArgs e)
        {
            dtp_Start_Time_Booking.MinDate = DateTime.Now;
            
        }

        private void dtp_Date_of_Booking_ValueChanged(object sender, EventArgs e)
        {
            dtp_Date_of_Booking.MinDate = DateTime.Today;
            dtp_Date_of_Booking.MaxDate = DateTime.Today.AddDays(10);
        }

        private void dtp_End_Time_Booking_ValueChanged(object sender, EventArgs e)
        {
            dtp_End_Time_Booking.MaxDate = dtp_Start_Time_Booking.Value.AddHours(Convert.ToInt32(txt_Admin.Text));
                
        }
    }
}
