﻿namespace QuantumArrangement
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbo_User_Id = new System.Windows.Forms.ComboBox();
            this.lbl_User = new System.Windows.Forms.Label();
            this.cbo_Resource = new System.Windows.Forms.ComboBox();
            this.lbl_Resource = new System.Windows.Forms.Label();
            this.dtp_Date_of_Booking = new System.Windows.Forms.DateTimePicker();
            this.dtp_Start_Time_Booking = new System.Windows.Forms.DateTimePicker();
            this.dtp_End_Time_Booking = new System.Windows.Forms.DateTimePicker();
            this.lbl_End_Time_Booking = new System.Windows.Forms.Label();
            this.lbl_Start_Time_Booking = new System.Windows.Forms.Label();
            this.lbl_Date = new System.Windows.Forms.Label();
            this.group_Booking = new System.Windows.Forms.GroupBox();
            this.group_Admin = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.group_Booking.SuspendLayout();
            this.group_Admin.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbo_User_Id
            // 
            this.cbo_User_Id.FormattingEnabled = true;
            this.cbo_User_Id.Location = new System.Drawing.Point(69, 12);
            this.cbo_User_Id.Name = "cbo_User_Id";
            this.cbo_User_Id.Size = new System.Drawing.Size(131, 21);
            this.cbo_User_Id.TabIndex = 0;
            this.cbo_User_Id.SelectedIndexChanged += new System.EventHandler(this.cbo_User_Id_SelectedIndexChanged);
            // 
            // lbl_User
            // 
            this.lbl_User.AutoSize = true;
            this.lbl_User.Location = new System.Drawing.Point(12, 15);
            this.lbl_User.Name = "lbl_User";
            this.lbl_User.Size = new System.Drawing.Size(32, 13);
            this.lbl_User.TabIndex = 1;
            this.lbl_User.Text = "User:";
            // 
            // cbo_Resource
            // 
            this.cbo_Resource.FormattingEnabled = true;
            this.cbo_Resource.Location = new System.Drawing.Point(61, 47);
            this.cbo_Resource.Name = "cbo_Resource";
            this.cbo_Resource.Size = new System.Drawing.Size(121, 21);
            this.cbo_Resource.TabIndex = 2;
            // 
            // lbl_Resource
            // 
            this.lbl_Resource.AutoSize = true;
            this.lbl_Resource.Location = new System.Drawing.Point(4, 50);
            this.lbl_Resource.Name = "lbl_Resource";
            this.lbl_Resource.Size = new System.Drawing.Size(53, 13);
            this.lbl_Resource.TabIndex = 3;
            this.lbl_Resource.Text = "Resource";
            // 
            // dtp_Date_of_Booking
            // 
            this.dtp_Date_of_Booking.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_Date_of_Booking.Location = new System.Drawing.Point(61, 136);
            this.dtp_Date_of_Booking.Name = "dtp_Date_of_Booking";
            this.dtp_Date_of_Booking.Size = new System.Drawing.Size(121, 20);
            this.dtp_Date_of_Booking.TabIndex = 4;
            // 
            // dtp_Start_Time_Booking
            // 
            this.dtp_Start_Time_Booking.Location = new System.Drawing.Point(61, 215);
            this.dtp_Start_Time_Booking.Name = "dtp_Start_Time_Booking";
            this.dtp_Start_Time_Booking.Size = new System.Drawing.Size(121, 20);
            this.dtp_Start_Time_Booking.TabIndex = 5;
            // 
            // dtp_End_Time_Booking
            // 
            this.dtp_End_Time_Booking.Location = new System.Drawing.Point(61, 292);
            this.dtp_End_Time_Booking.Name = "dtp_End_Time_Booking";
            this.dtp_End_Time_Booking.Size = new System.Drawing.Size(121, 20);
            this.dtp_End_Time_Booking.TabIndex = 6;
            // 
            // lbl_End_Time_Booking
            // 
            this.lbl_End_Time_Booking.AutoSize = true;
            this.lbl_End_Time_Booking.Location = new System.Drawing.Point(2, 292);
            this.lbl_End_Time_Booking.Name = "lbl_End_Time_Booking";
            this.lbl_End_Time_Booking.Size = new System.Drawing.Size(55, 13);
            this.lbl_End_Time_Booking.TabIndex = 7;
            this.lbl_End_Time_Booking.Text = "End Time:";
            // 
            // lbl_Start_Time_Booking
            // 
            this.lbl_Start_Time_Booking.AutoSize = true;
            this.lbl_Start_Time_Booking.Location = new System.Drawing.Point(2, 215);
            this.lbl_Start_Time_Booking.Name = "lbl_Start_Time_Booking";
            this.lbl_Start_Time_Booking.Size = new System.Drawing.Size(58, 13);
            this.lbl_Start_Time_Booking.TabIndex = 8;
            this.lbl_Start_Time_Booking.Text = "Start Time:";
            // 
            // lbl_Date
            // 
            this.lbl_Date.AutoSize = true;
            this.lbl_Date.Location = new System.Drawing.Point(2, 138);
            this.lbl_Date.Name = "lbl_Date";
            this.lbl_Date.Size = new System.Drawing.Size(30, 13);
            this.lbl_Date.TabIndex = 9;
            this.lbl_Date.Text = "Date";
            // 
            // group_Booking
            // 
            this.group_Booking.Controls.Add(this.lbl_Date);
            this.group_Booking.Controls.Add(this.lbl_Start_Time_Booking);
            this.group_Booking.Controls.Add(this.lbl_End_Time_Booking);
            this.group_Booking.Controls.Add(this.dtp_End_Time_Booking);
            this.group_Booking.Controls.Add(this.dtp_Start_Time_Booking);
            this.group_Booking.Controls.Add(this.dtp_Date_of_Booking);
            this.group_Booking.Controls.Add(this.lbl_Resource);
            this.group_Booking.Controls.Add(this.cbo_Resource);
            this.group_Booking.Enabled = false;
            this.group_Booking.Location = new System.Drawing.Point(8, 100);
            this.group_Booking.Name = "group_Booking";
            this.group_Booking.Size = new System.Drawing.Size(277, 357);
            this.group_Booking.TabIndex = 10;
            this.group_Booking.TabStop = false;
            // 
            // group_Admin
            // 
            this.group_Admin.Controls.Add(this.textBox1);
            this.group_Admin.Enabled = false;
            this.group_Admin.Location = new System.Drawing.Point(8, 57);
            this.group_Admin.Name = "group_Admin";
            this.group_Admin.Size = new System.Drawing.Size(277, 37);
            this.group_Admin.TabIndex = 11;
            this.group_Admin.TabStop = false;
            this.group_Admin.Text = "Admin";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(177, 11);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(593, 489);
            this.Controls.Add(this.group_Admin);
            this.Controls.Add(this.group_Booking);
            this.Controls.Add(this.lbl_User);
            this.Controls.Add(this.cbo_User_Id);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.group_Booking.ResumeLayout(false);
            this.group_Booking.PerformLayout();
            this.group_Admin.ResumeLayout(false);
            this.group_Admin.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbo_User_Id;
        private System.Windows.Forms.Label lbl_User;
        private System.Windows.Forms.ComboBox cbo_Resource;
        private System.Windows.Forms.Label lbl_Resource;
        private System.Windows.Forms.DateTimePicker dtp_Date_of_Booking;
        private System.Windows.Forms.DateTimePicker dtp_Start_Time_Booking;
        private System.Windows.Forms.DateTimePicker dtp_End_Time_Booking;
        private System.Windows.Forms.Label lbl_End_Time_Booking;
        private System.Windows.Forms.Label lbl_Start_Time_Booking;
        private System.Windows.Forms.Label lbl_Date;
        private System.Windows.Forms.GroupBox group_Booking;
        private System.Windows.Forms.GroupBox group_Admin;
        private System.Windows.Forms.TextBox textBox1;
    }
}

