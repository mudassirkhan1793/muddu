﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates
   
{

    public class Program
    {
        static void Main(string[] args)
        {

            Menu customer = new Menu();

            Console.Read();

        }


        
    }
    public class eating_Methods
    {

        public void Course_breads(string course)
        {
            Console.WriteLine(course, "{0}-with breads");
        }

        public void Course_soups(string course)
        {
            Console.WriteLine("{0}-with soup", course);
        }
        public void Course_appetizer(string course)
        {
            Console.WriteLine("{0}-with appetizer", course);
        }
        public void Course_maincourse(string course)
        {
            Console.WriteLine("{0}-with main course", course);
        }
        public void Course_sorbet(string course)
        {
            Console.WriteLine("{0}-with sorbet", course);
        }
        public void Course_dessert(string course)
        {
            Console.WriteLine("{0}-with dessert", course);
        }
        public void Course_coffee(string course)
        {
            Console.WriteLine("{0}-with coffee", course);
        }
    }


}
