﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates
{
    public delegate void Eat(string eat);

   public class Menu
    {
        public Menu()
        {
            eating_Methods obj = new eating_Methods();

            Eat eat1, eat2, eat3, eat4, eat5, eat6, eat7, eat_threecourse, eat_fivecourse, eat_sevencourse, eat_threecourse_as_diabetic, eat_fivecourse_as_diet;
            eat1 = new Eat(obj.Course_breads);
            eat2 = new Eat(obj.Course_soups);
            eat3 = new Eat(obj.Course_appetizer);
            eat4 = new Eat(obj.Course_maincourse);
            eat5 = new Eat(obj.Course_sorbet);
            eat6 = new Eat(obj.Course_dessert);
            eat7 = new Eat(obj.Course_coffee);


            eat_threecourse = eat3 + eat4 + eat6;
            eat_fivecourse = eat2 + eat3 + eat4 + eat6 + eat7;
            eat_sevencourse = eat1 + eat2 + eat3 + eat4 + eat5 + eat6 + eat7;

            eat_threecourse_as_diabetic = eat_threecourse - eat6;
            eat_fivecourse_as_diet = eat_fivecourse - eat6 - eat1;

            eat_fivecourse("EAT");

            
        }
    }
}
