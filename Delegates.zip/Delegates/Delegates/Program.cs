﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates
   
{

    public class Program
    {
        static void Main(string[] args)
        {
            
            Eat eat1, eat2, eat3, eat4, eat5, eat6, eat7, eat_threecourse, eat_fivecourse, eat_sevencourse, eat_threecourse_as_diabetic, eat_fivecourse_as_diet;
            eat1 = new Eat(obj.Course_breads);
            eat2 = new Eat(obj.Course_soups);
            eat3 = new Eat(obj.Course_appetizer);
            eat4 = new Eat(obj.Course_maincourse);
            eat5 = new Eat(obj.Course_sorbet);
            eat6 = new Eat(obj.Course_dessert);
            eat7 = new Eat(obj.Course_coffee);


            eat_threecourse = eat3 + eat4 + eat6;
            eat_fivecourse = eat2 + eat3 + eat4 + eat6 + eat7;
            eat_sevencourse = eat1 + eat2 + eat3 + eat4 + eat5 + eat6 + eat7;

            eat_threecourse_as_diabetic = eat_threecourse - eat6;
            eat_fivecourse_as_diet = eat_fivecourse - eat6 - eat1;

            eat_fivecourse("EAT");

            delegate_pointing obj1 = new delegate_pointing();
           

            Console.Read();

        }


        
    }
    public class eating_Methods
    {

        public void Course_breads(string course)
        {
            Console.WriteLine(course, "{0}-with breads");
        }

        public void Course_soups(string course)
        {
            Console.WriteLine("{0}-with soup", course);
        }
        public void Course_appetizer(string course)
        {
            Console.WriteLine("{0}-with appetizer", course);
        }
        public void Course_maincourse(string course)
        {
            Console.WriteLine("{0}-with main course", course);
        }
        public void Course_sorbet(string course)
        {
            Console.WriteLine("{0}-with sorbet", course);
        }
        public void Course_dessert(string course)
        {
            Console.WriteLine("{0}-with dessert", course);
        }
        public void Course_coffee(string course)
        {
            Console.WriteLine("{0}-with coffee", course);
        }
    }


}
