﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public class Hulls
    {
        public string Hull_Name { get; set; }
        public Joints joints { get; set; }
    }

    public enum Joints
    {
         Weld,
         Rivet,
         Bolt_Nut,
         Adhesive,        
    }
}
