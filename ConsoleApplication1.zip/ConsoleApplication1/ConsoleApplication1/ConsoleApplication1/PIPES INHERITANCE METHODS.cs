﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public   class Material_Properties_Conditions
    {

        public static int Youngs_Modulus_Steel;
        public static int Youngs_Modulus_Al;
        public static  int Stress = 120;
     
       
         
        public static double calculate_Constant()                                 // (1/4)*(pi=3.14)*(Stress)
        {
            double constant =(0.25 * 3.14 * Stress);
            return constant;
            
            
        }
        
    }

    public class Pipe:Material_Properties_Conditions
    {
        public double outer_Diameter;
        public double inner_Diameter;
        public double Area=0;
        public double Load ;

        public virtual void  Calculate_Load()
        {


            double Load = calculate_Constant() * ((Math.Pow(outer_Diameter,2)) - ((Math.Pow(inner_Diameter, 2))));

            //return outer_Diameter;

            Console.WriteLine("the Load is:{0}", Load);

            
        }
              

    }

    public class Pipe_Metrics_Various:Pipe
    {
        public new void  Calculate_Load()
        {

            double Load = 0.000145*((calculate_Constant()) * ((Math.Pow(outer_Diameter, 2) - (Math.Pow(inner_Diameter, 2)))));

            //return outer_Diameter;

            Console.WriteLine("the Load in __pound per square inch is:{0}", Load);
        }
    }
    

   
   public class Program
    {
        
        public static void Main(string[] args)
        {

            #region Pipe_Inheritance
            Pipe pipe1 = new Pipe_Metrics_Various();
            pipe1.inner_Diameter = 110;
            pipe1.outer_Diameter = 120;
            pipe1.Calculate_Load();

            Pipe pipe2 = new Pipe_Metrics_Various();
            pipe2.inner_Diameter = 50;
            pipe2.outer_Diameter = 120;
            pipe2.Calculate_Load();

            Pipe pipe3 = new Pipe_Metrics_Various();
            pipe3.inner_Diameter = 70;
            pipe3.outer_Diameter = 120;
            pipe3.Calculate_Load();

            double Load_Condition = 400000.00;

            Console.WriteLine("Enter the first assembled pipe:");

            Start:
            int selection = Convert.ToInt32(Console.ReadLine());

            switch (selection)
            {
                case 1:

                    if (pipe1.Load >= Load_Condition)
                    {
                        Console.WriteLine("Enter Next Pipe Selection:");
                        goto Start;
                    }
                    else
                    {
                        Console.WriteLine("Pipe Cannot withstand Load");
                        goto Start;
                    }
                    break;



                case 2:
                    if (pipe2.Load <= Load_Condition)
                    {
                        Console.WriteLine("Enter Next Pipe Selection:");
                        goto Start;
                    }
                    else
                    {
                        Console.WriteLine("Pipe Cannot withstand Load");
                        goto Start;
                    }

                    break;

                case 3:
                    if (pipe1.Load <= Load_Condition)
                    {
                        Console.WriteLine("Enter Next Pipe Selection:");
                        goto Start;
                    }
                    else
                    {
                        Console.WriteLine("Pipe Cannot withstand Load");
                        goto Start;
                    }

                    break;
            }

            #endregion

            #region Enums_Joints


            Hulls[] HullPanel = new Hulls[16];

            HullPanel[0] = new Hulls
            {
                Hull_Name = "1",
                joints = Joints.Weld

            };

            HullPanel[2] = new Hulls
            {
                Hull_Name = "2",
                joints = Joints.Adhesive
            };

            HullPanel[2] = new Hulls
            {
                Hull_Name = "3",
                joints = Joints.Rivet
            }; HullPanel[2] = new Hulls
            {
                Hull_Name = "4",
                joints = Joints.Rivet
            }; HullPanel[2] = new Hulls
            {
                Hull_Name = "5",
                joints = Joints.Bolt_Nut
            };

            #endregion

            Console.WriteLine("--------");
            Console.Read();


        }
    }
}
