﻿namespace Find_and_Filter
{
    partial class Find
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_FindResults = new System.Windows.Forms.DataGridView();
            this.txt_EmpId = new System.Windows.Forms.TextBox();
            this.txt_Email = new System.Windows.Forms.TextBox();
            this.txt_LastNmae = new System.Windows.Forms.TextBox();
            this.txt_FirstName = new System.Windows.Forms.TextBox();
            this.lbl_EmpId = new System.Windows.Forms.Label();
            this.lbl_LastName = new System.Windows.Forms.Label();
            this.lbl_Gender = new System.Windows.Forms.Label();
            this.lbl_Email = new System.Windows.Forms.Label();
            this.lbl_Designation = new System.Windows.Forms.Label();
            this.lbl_FirstName = new System.Windows.Forms.Label();
            this.btn_Find_in_Find_Dialog = new System.Windows.Forms.Button();
            this.txt_Designation = new System.Windows.Forms.TextBox();
            this.txt_Gender = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_FindResults)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_FindResults
            // 
            this.dgv_FindResults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_FindResults.Location = new System.Drawing.Point(429, 12);
            this.dgv_FindResults.Name = "dgv_FindResults";
            this.dgv_FindResults.Size = new System.Drawing.Size(582, 405);
            this.dgv_FindResults.TabIndex = 0;
            // 
            // txt_EmpId
            // 
            this.txt_EmpId.Location = new System.Drawing.Point(165, 34);
            this.txt_EmpId.Name = "txt_EmpId";
            this.txt_EmpId.Size = new System.Drawing.Size(184, 20);
            this.txt_EmpId.TabIndex = 1;
            // 
            // txt_Email
            // 
            this.txt_Email.Location = new System.Drawing.Point(165, 319);
            this.txt_Email.Name = "txt_Email";
            this.txt_Email.Size = new System.Drawing.Size(184, 20);
            this.txt_Email.TabIndex = 3;
            // 
            // txt_LastNmae
            // 
            this.txt_LastNmae.Location = new System.Drawing.Point(165, 171);
            this.txt_LastNmae.Name = "txt_LastNmae";
            this.txt_LastNmae.Size = new System.Drawing.Size(184, 20);
            this.txt_LastNmae.TabIndex = 5;
            // 
            // txt_FirstName
            // 
            this.txt_FirstName.Location = new System.Drawing.Point(165, 104);
            this.txt_FirstName.Name = "txt_FirstName";
            this.txt_FirstName.Size = new System.Drawing.Size(184, 20);
            this.txt_FirstName.TabIndex = 6;
            // 
            // lbl_EmpId
            // 
            this.lbl_EmpId.AutoSize = true;
            this.lbl_EmpId.Location = new System.Drawing.Point(35, 37);
            this.lbl_EmpId.Name = "lbl_EmpId";
            this.lbl_EmpId.Size = new System.Drawing.Size(37, 13);
            this.lbl_EmpId.TabIndex = 8;
            this.lbl_EmpId.Text = "EmpId";
            // 
            // lbl_LastName
            // 
            this.lbl_LastName.AutoSize = true;
            this.lbl_LastName.Location = new System.Drawing.Point(35, 174);
            this.lbl_LastName.Name = "lbl_LastName";
            this.lbl_LastName.Size = new System.Drawing.Size(58, 13);
            this.lbl_LastName.TabIndex = 9;
            this.lbl_LastName.Text = "Last Name";
            // 
            // lbl_Gender
            // 
            this.lbl_Gender.AutoSize = true;
            this.lbl_Gender.Location = new System.Drawing.Point(35, 243);
            this.lbl_Gender.Name = "lbl_Gender";
            this.lbl_Gender.Size = new System.Drawing.Size(42, 13);
            this.lbl_Gender.TabIndex = 10;
            this.lbl_Gender.Text = "Gender";
            // 
            // lbl_Email
            // 
            this.lbl_Email.AutoSize = true;
            this.lbl_Email.Location = new System.Drawing.Point(35, 322);
            this.lbl_Email.Name = "lbl_Email";
            this.lbl_Email.Size = new System.Drawing.Size(32, 13);
            this.lbl_Email.TabIndex = 11;
            this.lbl_Email.Text = "Email";
            // 
            // lbl_Designation
            // 
            this.lbl_Designation.AutoSize = true;
            this.lbl_Designation.Location = new System.Drawing.Point(35, 400);
            this.lbl_Designation.Name = "lbl_Designation";
            this.lbl_Designation.Size = new System.Drawing.Size(63, 13);
            this.lbl_Designation.TabIndex = 12;
            this.lbl_Designation.Text = "Designation";
            // 
            // lbl_FirstName
            // 
            this.lbl_FirstName.AutoSize = true;
            this.lbl_FirstName.Location = new System.Drawing.Point(35, 107);
            this.lbl_FirstName.Name = "lbl_FirstName";
            this.lbl_FirstName.Size = new System.Drawing.Size(57, 13);
            this.lbl_FirstName.TabIndex = 13;
            this.lbl_FirstName.Text = "First Name";
            // 
            // btn_Find_in_Find_Dialog
            // 
            this.btn_Find_in_Find_Dialog.Location = new System.Drawing.Point(165, 497);
            this.btn_Find_in_Find_Dialog.Name = "btn_Find_in_Find_Dialog";
            this.btn_Find_in_Find_Dialog.Size = new System.Drawing.Size(184, 90);
            this.btn_Find_in_Find_Dialog.TabIndex = 16;
            this.btn_Find_in_Find_Dialog.Text = "Find";
            this.btn_Find_in_Find_Dialog.UseVisualStyleBackColor = true;
            this.btn_Find_in_Find_Dialog.Click += new System.EventHandler(this.btn_Find_in_Find_Dialog_Click);
            // 
            // txt_Designation
            // 
            this.txt_Designation.Location = new System.Drawing.Point(165, 393);
            this.txt_Designation.Name = "txt_Designation";
            this.txt_Designation.Size = new System.Drawing.Size(184, 20);
            this.txt_Designation.TabIndex = 17;
            // 
            // txt_Gender
            // 
            this.txt_Gender.Location = new System.Drawing.Point(165, 236);
            this.txt_Gender.Name = "txt_Gender";
            this.txt_Gender.Size = new System.Drawing.Size(184, 20);
            this.txt_Gender.TabIndex = 18;
            // 
            // Find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1023, 625);
            this.Controls.Add(this.txt_Gender);
            this.Controls.Add(this.txt_Designation);
            this.Controls.Add(this.btn_Find_in_Find_Dialog);
            this.Controls.Add(this.lbl_FirstName);
            this.Controls.Add(this.lbl_Designation);
            this.Controls.Add(this.lbl_Email);
            this.Controls.Add(this.lbl_Gender);
            this.Controls.Add(this.lbl_LastName);
            this.Controls.Add(this.lbl_EmpId);
            this.Controls.Add(this.txt_FirstName);
            this.Controls.Add(this.txt_LastNmae);
            this.Controls.Add(this.txt_Email);
            this.Controls.Add(this.txt_EmpId);
            this.Controls.Add(this.dgv_FindResults);
            this.Name = "Find";
            this.Text = "Find";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_FindResults)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_FindResults;
        private System.Windows.Forms.TextBox txt_EmpId;
        private System.Windows.Forms.TextBox txt_Email;
        private System.Windows.Forms.TextBox txt_LastNmae;
        private System.Windows.Forms.TextBox txt_FirstName;
        private System.Windows.Forms.Label lbl_EmpId;
        private System.Windows.Forms.Label lbl_LastName;
        private System.Windows.Forms.Label lbl_Gender;
        private System.Windows.Forms.Label lbl_Email;
        private System.Windows.Forms.Label lbl_Designation;
        private System.Windows.Forms.Label lbl_FirstName;
        private System.Windows.Forms.Button btn_Find_in_Find_Dialog;
        private System.Windows.Forms.TextBox txt_Designation;
        private System.Windows.Forms.TextBox txt_Gender;
    }
}