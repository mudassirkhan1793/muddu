﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Find_and_Filter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'find_and_FilterDataSet1.Employee_Table' table. You can move, or remove it, as needed.
            this.employee_TableTableAdapter.Fill(this.find_and_FilterDataSet1.Employee_Table);
            // TODO: This line of code loads data into the 'find_and_FilterDataSet.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter.Fill(this.find_and_FilterDataSet.Table);

            
        }

        private void btn_Find_Click(object sender, EventArgs e)
        {
            Find Find = new Find();
            Find.Show();
        }

        private void btn_Filter_Click(object sender, EventArgs e)
        {
            Filter Filter = new Filter();
            Filter.Show();
        }
    }
}
