﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Find_and_Filter
{
    public partial class Filter : Form
    {
        public Filter()
        {
            InitializeComponent();
        }

        private void btn_Filter_Click(object sender, EventArgs e)
        {
            string connectionstring = ConfigurationManager.ConnectionStrings["Find_and_Filter.Properties.Settings.Find_and_FilterConnectionString"].ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionstring))
            {

                try
                {
                    SqlDataAdapter da = new SqlDataAdapter("usp_Filter", con);
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;


                    da.SelectCommand.Parameters.AddWithValue("@EmpId", txt_Filter_EmpId.Text);


                    da.SelectCommand.Parameters.AddWithValue("@FirstName", txt_Filter_FirstName.Text);


                    da.SelectCommand.Parameters.AddWithValue("@LastName", txt_Filter_LastName.Text);

                    da.SelectCommand.Parameters.AddWithValue("@email", txt_Filter_email.Text);


                    da.SelectCommand.Parameters.AddWithValue("@Gender", txt_Filter_Gender.Text);

                    da.SelectCommand.Parameters.AddWithValue("@Designation", txt_Filter_Designation.Text);



                    DataSet ds = new DataSet();
                    da.Fill(ds, "Employee_Table");

                    dgv_FilterResults.DataSource = ds;
                    dgv_FilterResults.DataMember = "Employee_Table";









                }
                catch (Exception ex)
                {

                    MessageBox.Show(""+ ex.ToString());
                }



            }
        }
    }
}
