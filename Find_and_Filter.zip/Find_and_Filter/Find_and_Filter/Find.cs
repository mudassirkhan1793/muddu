﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace Find_and_Filter
{
    public partial class Find : Form
    {
        public Find()
        {
            InitializeComponent();
        }

        private void btn_Find_in_Find_Dialog_Click(object sender, EventArgs e)
        {
            string connectionstring = ConfigurationManager.ConnectionStrings["Find_and_Filter.Properties.Settings.Find_and_FilterConnectionString"].ConnectionString;
            
            using (SqlConnection con = new SqlConnection(connectionstring))
            {

                try
                {
                    SqlDataAdapter da = new SqlDataAdapter("storedprocedureforfind", con);
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;


                    da.SelectCommand.Parameters.AddWithValue("@EmpId",txt_EmpId.Text );


                    da.SelectCommand.Parameters.AddWithValue("@FirstName", txt_FirstName.Text);


                    da.SelectCommand.Parameters.AddWithValue("@LastName", txt_LastNmae.Text);
                    
                    da.SelectCommand.Parameters.AddWithValue("@email", txt_Email.Text);


                    da.SelectCommand.Parameters.AddWithValue("@Gender", txt_Gender.Text);

                    da.SelectCommand.Parameters.AddWithValue("@Designation", txt_Designation.Text);



                    DataSet ds = new DataSet();
                    da.Fill(ds, "Employee_Table");

                    dgv_FindResults.DataSource = ds;
                    dgv_FindResults.DataMember = "Employee_Table";


                    
                    
                    
                    


                    
                }
                catch (Exception ex)
                {

                    MessageBox.Show("", ex.ToString());
                }
                
               

            }
        }

    }
}
