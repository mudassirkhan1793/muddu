﻿namespace Find_and_Filter
{
    partial class Filter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_FilterResults = new System.Windows.Forms.DataGridView();
            this.txt_Filter_EmpId = new System.Windows.Forms.TextBox();
            this.txt_Filter_Designation = new System.Windows.Forms.TextBox();
            this.txt_Filter_email = new System.Windows.Forms.TextBox();
            this.txt_Filter_LastName = new System.Windows.Forms.TextBox();
            this.txt_Filter_FirstName = new System.Windows.Forms.TextBox();
            this.btn_Filter = new System.Windows.Forms.Button();
            this.cmb_Filter_Gender = new System.Windows.Forms.ComboBox();
            this.txt_Filter_Gender = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_FilterResults)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_FilterResults
            // 
            this.dgv_FilterResults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_FilterResults.Location = new System.Drawing.Point(288, 28);
            this.dgv_FilterResults.Name = "dgv_FilterResults";
            this.dgv_FilterResults.Size = new System.Drawing.Size(605, 536);
            this.dgv_FilterResults.TabIndex = 0;
            // 
            // txt_Filter_EmpId
            // 
            this.txt_Filter_EmpId.Location = new System.Drawing.Point(12, 75);
            this.txt_Filter_EmpId.Name = "txt_Filter_EmpId";
            this.txt_Filter_EmpId.Size = new System.Drawing.Size(190, 20);
            this.txt_Filter_EmpId.TabIndex = 1;
            // 
            // txt_Filter_Designation
            // 
            this.txt_Filter_Designation.Location = new System.Drawing.Point(12, 307);
            this.txt_Filter_Designation.Name = "txt_Filter_Designation";
            this.txt_Filter_Designation.Size = new System.Drawing.Size(190, 20);
            this.txt_Filter_Designation.TabIndex = 2;
            // 
            // txt_Filter_email
            // 
            this.txt_Filter_email.Location = new System.Drawing.Point(12, 246);
            this.txt_Filter_email.Name = "txt_Filter_email";
            this.txt_Filter_email.Size = new System.Drawing.Size(190, 20);
            this.txt_Filter_email.TabIndex = 3;
            // 
            // txt_Filter_LastName
            // 
            this.txt_Filter_LastName.Location = new System.Drawing.Point(12, 183);
            this.txt_Filter_LastName.Name = "txt_Filter_LastName";
            this.txt_Filter_LastName.Size = new System.Drawing.Size(190, 20);
            this.txt_Filter_LastName.TabIndex = 4;
            // 
            // txt_Filter_FirstName
            // 
            this.txt_Filter_FirstName.Location = new System.Drawing.Point(12, 125);
            this.txt_Filter_FirstName.Name = "txt_Filter_FirstName";
            this.txt_Filter_FirstName.Size = new System.Drawing.Size(190, 20);
            this.txt_Filter_FirstName.TabIndex = 5;
            // 
            // btn_Filter
            // 
            this.btn_Filter.Location = new System.Drawing.Point(36, 433);
            this.btn_Filter.Name = "btn_Filter";
            this.btn_Filter.Size = new System.Drawing.Size(166, 103);
            this.btn_Filter.TabIndex = 6;
            this.btn_Filter.Text = "Filter";
            this.btn_Filter.UseVisualStyleBackColor = true;
            this.btn_Filter.Click += new System.EventHandler(this.btn_Filter_Click);
            // 
            // cmb_Filter_Gender
            // 
            this.cmb_Filter_Gender.FormattingEnabled = true;
            this.cmb_Filter_Gender.Items.AddRange(new object[] {
            "M",
            "F"});
            this.cmb_Filter_Gender.Location = new System.Drawing.Point(54, 360);
            this.cmb_Filter_Gender.Name = "cmb_Filter_Gender";
            this.cmb_Filter_Gender.Size = new System.Drawing.Size(64, 21);
            this.cmb_Filter_Gender.TabIndex = 7;
            // 
            // txt_Filter_Gender
            // 
            this.txt_Filter_Gender.Location = new System.Drawing.Point(12, 398);
            this.txt_Filter_Gender.Name = "txt_Filter_Gender";
            this.txt_Filter_Gender.Size = new System.Drawing.Size(190, 20);
            this.txt_Filter_Gender.TabIndex = 8;
            // 
            // Filter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(918, 625);
            this.Controls.Add(this.txt_Filter_Gender);
            this.Controls.Add(this.cmb_Filter_Gender);
            this.Controls.Add(this.btn_Filter);
            this.Controls.Add(this.txt_Filter_FirstName);
            this.Controls.Add(this.txt_Filter_LastName);
            this.Controls.Add(this.txt_Filter_email);
            this.Controls.Add(this.txt_Filter_Designation);
            this.Controls.Add(this.txt_Filter_EmpId);
            this.Controls.Add(this.dgv_FilterResults);
            this.Name = "Filter";
            this.Text = "Filter";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_FilterResults)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_FilterResults;
        private System.Windows.Forms.TextBox txt_Filter_EmpId;
        private System.Windows.Forms.TextBox txt_Filter_Designation;
        private System.Windows.Forms.TextBox txt_Filter_email;
        private System.Windows.Forms.TextBox txt_Filter_LastName;
        private System.Windows.Forms.TextBox txt_Filter_FirstName;
        private System.Windows.Forms.Button btn_Filter;
        private System.Windows.Forms.ComboBox cmb_Filter_Gender;
        private System.Windows.Forms.TextBox txt_Filter_Gender;
    }
}